'use strict';

const PIECES = { K:'♔', Q:'♕', R:'♖', B:'♗', N:'♘', P:'♙', k:'♚', q:'♛', r:'♜', b:'♝', n:'♞', p:'♟' };
const state = {
  id: null, mode: 'bot', difficulty: 'medium', color: 'white', room: null, socket: null,
  fen: null, legalMoves: new Set(), selected: null, flipped: false, lastData: null,
  history: [], clocks: [600, 600], clockEnabled: true, clockTurn: null, clockLastAt: 0,
  clockTick: null, clockEnded: false, finished: false, finishSaved: false
};
const $ = id => document.getElementById(id);

async function api(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({ error: 'The server returned an unreadable response.' }));
  if (!response.ok) throw new Error(data.error || 'The request failed.');
  return data;
}

function toast(message, type = 'info') {
  const container = $('toastContainer');
  if (!container) return;
  const item = document.createElement('div');
  item.className = `toast toast-${type}`;
  item.textContent = message;
  container.append(item);
  window.setTimeout(() => item.remove(), 3600);
}

function showSection(id) {
  document.querySelectorAll('.app-section').forEach(section => section.classList.toggle('active', section.id === id));
  const activeLink = document.querySelector(`.nav-link[data-target="${id}"]`);
  document.querySelectorAll('.nav-link').forEach(link => link.classList.toggle('active', link === activeLink));
  $('pageTitle').textContent = ({ homeSection:'Dashboard', gameSection:'Game', statsSection:'Leaderboard', historySection:'Game History' })[id] || 'Chess Arena';
  $('sidebar')?.classList.remove('sidebar-open');
  $('sidebarOverlay')?.classList.remove('overlay-visible');
  if (id === 'historySection') loadHistory();
}

function pieceLabel(piece) {
  return ({ K:'white king', Q:'white queen', R:'white rook', B:'white bishop', N:'white knight', P:'white pawn', k:'black king', q:'black queen', r:'black rook', b:'black bishop', n:'black knight', p:'black pawn' })[piece];
}

function parseFen(fen) {
  const squares = Array(64).fill(null);
  fen.split(' ')[0].split('/').forEach((rank, y) => {
    let file = 0;
    for (const token of rank) {
      if (/^[1-8]$/.test(token)) file += Number(token);
      else squares[y * 8 + file++] = token;
    }
  });
  return squares;
}

function render(data) {
  state.lastData = data;
  state.fen = data.fen;
  state.legalMoves = new Set(data.legal_moves || []);
  state.history = data.moves || [];
  const squares = parseFen(data.fen);
  const board = $('chessboard');
  board.replaceChildren();
  for (let index = 0; index < 64; index++) {
    const square = state.flipped ? 63 - index : index;
    const file = square % 8;
    const rank = 7 - Math.floor(square / 8);
    const algebraic = 'abcdefgh'[file] + (rank + 1);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `square ${(Math.floor(square / 8) + file) % 2 ? 'dark-square' : 'light-square'}`;
    button.dataset.square = algebraic;
    button.setAttribute('aria-label', `${algebraic}${squares[square] ? ` ${pieceLabel(squares[square])}` : ''}`);
    if (squares[square]) {
      const piece = document.createElement('span');
      piece.className = `piece ${squares[square] === squares[square].toUpperCase() ? 'white-piece' : 'black-piece'}`;
      piece.textContent = PIECES[squares[square]];
      button.append(piece);
    }
    if (state.selected === algebraic) button.classList.add('selected-square');
    if (state.selected && state.legalMoves.has(state.selected + algebraic)) button.classList.add('legal-target');
    button.addEventListener('click', () => handleSquare(algebraic, squares[square]));
    board.append(button);
  }
  $('turnIndicator').textContent = data.game_over ? 'Game over' : `${data.turn === 'white' ? 'White' : 'Black'} to move${data.check ? ' · Check' : ''}`;
  $('gameMessage').textContent = data.game_over ? `${data.status || 'Finished'} · ${data.result}` : 'Game in progress';
  $('moveCount').textContent = String(Math.ceil(state.history.length / 2));
  renderMoveHistory();
  updateClocks(data.clocks, data.turn);
  if (data.game_over && state.mode !== 'online') completeGame(data);
}

function renderMoveHistory() {
  const container = $('moveHistory');
  container.replaceChildren();
  for (let i = 0; i < state.history.length; i += 2) {
    const row = document.createElement('div');
    row.className = 'move-row';
    for (const text of [String(Math.floor(i / 2) + 1) + '.', state.history[i], state.history[i + 1] || '']) {
      const cell = document.createElement('span');
      cell.textContent = text;
      row.append(cell);
    }
    container.append(row);
  }
  container.lastElementChild?.scrollIntoView({ block: 'nearest' });
}

function handleSquare(square, piece) {
  if (state.finished || state.clockEnded || !state.fen) return;
  if (state.mode === 'online') return handleOnlineSquare(square, piece);
  if (!state.id || (state.mode === 'bot' && state.lastData?.turn !== 'white')) return;
  if (state.selected && state.legalMoves.has(state.selected + square)) {
    let move = state.selected + square;
    if ((square[1] === '8' && state.selected[1] === '7') || (square[1] === '1' && state.selected[1] === '2')) move += promotionChoice();
    state.selected = null;
    sendMove(move);
  } else {
    const ownPiece = piece && (state.mode === 'bot' ? piece === piece.toUpperCase() : true);
    state.selected = ownPiece ? square : null;
    render(state.lastData);
  }
}

function promotionChoice() {
  const choice = window.prompt('Promote to queen, rook, bishop, or knight?', 'q');
  return ({ q:'q', r:'r', b:'b', n:'n' })[(choice || 'q').toLowerCase()] || 'q';
}

async function sendMove(move) {
  try {
    const data = await api(`/api/games/${encodeURIComponent(state.id)}/move`, { method: 'POST', body: JSON.stringify({ move }) });
    state.selected = null;
    render(data);
    if (state.mode === 'bot' && !data.game_over) await botMove();
  } catch (error) { toast(error.message, 'error'); }
}

async function botMove() {
  try {
    const data = await window.ChessArenaBot.move(state.id, state.difficulty);
    render(data);
  } catch (error) { toast(error.message, 'error'); }
}

function clockSeconds() {
  const value = Number($('clockSetting').value);
  return Number.isFinite(value) ? value : 600;
}

async function startGame(mode = 'bot') {
  closeRoom();
  state.mode = mode;
  state.id = null;
  state.room = null;
  state.finished = false;
  state.finishSaved = false;
  state.clockEnded = false;
  state.selected = null;
  state.flipped = false;
  state.clockTurn = null;
  clearInterval(state.clockTick);
  const seconds = clockSeconds();
  state.clocks = [seconds, seconds];
  state.clockEnabled = seconds > 0;
  state.difficulty = $('botDifficulty').value;
  try {
    const data = await api('/api/games', { method:'POST', body:JSON.stringify({ mode, difficulty:state.difficulty }) });
    state.id = data.game_id;
    $('roomCodeDisplay').hidden = true;
    $('opponentName').textContent = mode === 'bot' ? `Chess Bot · ${state.difficulty}` : 'Local opponent';
    $('playerName').textContent = mode === 'bot' ? 'You · White' : 'Player 1 · White';
    render(data);
    showSection('gameSection');
    beginClock(data.turn);
  } catch (error) { toast(error.message, 'error'); }
}

function updateClocks(serverClocks, turn) {
  if (Array.isArray(serverClocks)) state.clocks = serverClocks.map(n => Math.max(0, Math.ceil(n)));
  $('playerTimer').textContent = formatTime(state.clocks[state.mode === 'online' && state.color === 'black' ? 1 : 0]);
  $('opponentTimer').textContent = formatTime(state.clocks[state.mode === 'online' && state.color === 'black' ? 0 : 1]);
  if (turn && turn !== state.clockTurn) beginClock(turn);
}

function beginClock(turn) {
  state.clockTurn = turn;
  clearInterval(state.clockTick);
  if (!state.clockEnabled || state.finished) return;
  state.clockLastAt = Date.now();
  state.clockTick = window.setInterval(() => {
    const now = Date.now();
    const elapsed = (now - state.clockLastAt) / 1000;
    state.clockLastAt = now;
    const index = turn === 'white' ? 0 : 1;
    state.clocks[index] = Math.max(0, state.clocks[index] - elapsed);
    updateClocks();
    if (state.clocks[index] <= 0) {
      clearInterval(state.clockTick);
      if (state.mode === 'online') {
        state.socket?.emit('room_clock_check', { room:state.room });
      } else {
        state.clockEnded = true;
        const result = turn === 'white' ? 'loss' : 'win';
        $('gameMessage').textContent = `${turn === 'white' ? 'White' : 'Black'} lost on time`;
        completeByReason(result, 'timeout');
      }
    }
  }, 200);
}

function formatTime(seconds) {
  const remaining = Math.max(0, Math.ceil(seconds));
  return `${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, '0')}`;
}

async function undo() {
  if (!state.id || state.mode === 'online' || state.finished) return;
  try {
    state.selected = null;
    render(await api(`/api/games/${encodeURIComponent(state.id)}/undo`, { method:'POST', body:'{}' }));
  } catch (error) { toast(error.message, 'error'); }
}

async function completeGame(data) {
  if (state.finishSaved) return;
  state.finished = true;
  state.finishSaved = true;
  clearInterval(state.clockTick);
  const result = ({ '1-0':'win', '0-1':'loss', '1/2-1/2':'draw' })[data.result];
  if (result) await saveResult(result, 'finished');
}

async function completeByReason(result, reason) {
  if (state.finishSaved || !state.id) return;
  state.finished = true;
  state.finishSaved = true;
  clearInterval(state.clockTick);
  await saveResult(result, reason);
}

async function saveResult(result, reason) {
  try {
    const saved = await api(`/api/games/${encodeURIComponent(state.id)}/finish`, {
      method:'POST', body:JSON.stringify({ result, reason, opponent:$('opponentName').textContent })
    });
    if (saved.saved) { await loadProfile(); await loadHistory(); }
  } catch (error) { toast(error.message, 'error'); }
}

async function resign() {
  if (state.mode === 'online' && state.room) {
    window.ChessArenaMultiplayer.resign(state.socket, state.room);
    return;
  }
  if (state.id && !state.finished) {
    await completeByReason('loss', 'resign');
    $('gameMessage').textContent = 'You resigned.';
    toast('Game resigned.', 'info');
  }
}

function closeRoom() {
  clearInterval(state.clockTick);
  if (state.socket) state.socket.disconnect();
  state.socket = null;
  state.room = null;
  $('roomCodeDisplay').hidden = true;
}

function startOnline(roomCode = '') {
  closeRoom();
  state.mode = 'online';
  state.id = null;
  state.finished = false;
  state.finishSaved = false;
  state.clockEnded = false;
  state.selected = null;
  state.clockTurn = null;
  state.clockEnabled = clockSeconds() > 0;
  state.clocks = [clockSeconds(), clockSeconds()];
  $('opponentName').textContent = 'Waiting for opponent…';
  $('playerName').textContent = 'Connecting…';
  $('roomCodeDisplay').hidden = true;
  showSection('gameSection');
  try {
    state.socket = window.ChessArenaMultiplayer.connect({
      roomCode,
      clockSeconds:clockSeconds(),
      onState: data => {
        if (data.room) {
          state.room = data.room;
          if (data.color) state.color = data.color;
          if (data.color) state.flipped = data.color === 'black';
          $('roomCodeText').textContent = data.room;
          $('roomCodeDisplay').hidden = false;
          if (data.color) $('playerName').textContent = `You · ${data.color}`;
        }
        if (Number.isFinite(data.players)) $('opponentName').textContent = data.players > 1 ? 'Online opponent' : 'Waiting for opponent…';
        state.selected = null;
        render(data);
      },
      onNotice:(message, error) => toast(message, error ? 'error' : 'info'),
      onOver: data => {
        state.finished = true;
        clearInterval(state.clockTick);
        const ownWin = data.winner === state.color;
        $('gameMessage').textContent = data.winner ? (ownWin ? 'You won.' : 'You lost.') : `Draw · ${data.result || ''}`;
        $('turnIndicator').textContent = 'Game over';
        loadProfile();
        loadHistory();
      },
      onClock: data => { state.clocks = data.clocks; updateClocks(data.clocks, data.turn); }
    });
  } catch (error) { toast(error.message, 'error'); }
}

function handleOnlineSquare(square, piece) {
  if (!state.room || state.finished) return;
  const own = piece && ((state.color === 'white') === (piece === piece.toUpperCase()));
  if (state.selected && state.legalMoves.has(state.selected + square)) {
    let move = state.selected + square;
    if ((square[1] === '8' && state.selected[1] === '7') || (square[1] === '1' && state.selected[1] === '2')) move += promotionChoice();
    window.ChessArenaMultiplayer.move(state.socket, state.room, move);
    state.selected = null;
    render(state.lastData);
  } else {
    state.selected = own ? square : null;
    render(state.lastData);
  }
}

async function loadProfile() {
  try {
    const profile = await api('/api/me');
    $('gamesPlayed').textContent = profile.games;
    $('gamesWon').textContent = profile.wins;
    $('gamesLost').textContent = profile.losses;
    $('gamesDrawn').textContent = profile.draws;
    $('winRate').textContent = `${profile.win_rate}%`;
    $('profileName').textContent = profile.user || 'Guest';
    $('logoutButton').hidden = !profile.user;
    $('loginButton').hidden = !!profile.user;
    $('registerButton').hidden = !!profile.user;
  } catch (error) { toast(error.message, 'error'); }
}

async function authenticate(path) {
  try {
    const credentials = { username:$('accountUsername').value.trim(), password:$('accountPassword').value };
    await api(path, { method:'POST', body:JSON.stringify(credentials) });
    $('accountPassword').value = '';
    toast(path.endsWith('login') ? 'Welcome back.' : 'Account created.', 'success');
    await loadProfile();
    await loadHistory();
  } catch (error) { toast(error.message, 'error'); }
}

async function loadLeaderboard() {
  const target = $('leaderboardContent');
  try {
    const data = await api('/api/leaderboard');
    target.replaceChildren();
    if (!data.players.length) { target.textContent = 'No recorded games yet.'; return; }
    const list = document.createElement('ol');
    list.className = 'leaderboard';
    data.players.forEach(player => {
      const row = document.createElement('li');
      const name = document.createElement('span'); name.textContent = player.username;
      const stats = document.createElement('span'); stats.textContent = `${player.wins} wins · ${player.games} games`;
      row.append(name, stats); list.append(row);
    });
    target.append(list);
  } catch (error) { target.textContent = error.message; }
}

async function loadHistory() {
  const target = $('historyContent');
  if (!target) return;
  try {
    const data = await api('/api/history');
    target.replaceChildren();
    if (!data.games.length) { target.textContent = 'No saved games yet. Play a game while signed in to add it here.'; return; }
    data.games.forEach(game => {
      const details = document.createElement('details');
      details.className = 'history-game';
      const summary = document.createElement('summary');
      const date = new Date(game.played_at);
      summary.textContent = `${game.result.toUpperCase()} · vs ${game.opponent} · ${Number.isNaN(date.valueOf()) ? game.played_at : date.toLocaleString()}`;
      const pgn = document.createElement('pre'); pgn.textContent = game.pgn || 'Move record unavailable.';
      details.append(summary, pgn); target.append(details);
    });
  } catch (error) { target.textContent = error.message; }
}

async function logout() {
  try { await api('/api/logout', { method:'POST', body:'{}' }); await loadProfile(); await loadHistory(); toast('Signed out.', 'info'); }
  catch (error) { toast(error.message, 'error'); }
}

function init() {
  document.documentElement.classList.remove('no-js');
  document.documentElement.classList.add('js-ready');
  document.querySelectorAll('.nav-link').forEach(link => link.addEventListener('click', event => { event.preventDefault(); showSection(link.dataset.target); }));
  $('heroPlayButton').addEventListener('click', () => startGame('bot'));
  $('botPlayButton').addEventListener('click', () => startGame('bot'));
  $('onlinePlayButton').addEventListener('click', () => startOnline());
  $('friendPlayButton').addEventListener('click', () => {
    const code = window.prompt('Enter the room code your friend shared with you.');
    if (code?.trim()) startOnline(code.trim());
  });
  $('localPlayButton').addEventListener('click', () => startGame('local'));
  $('newGameButton').addEventListener('click', () => state.mode === 'online' ? startOnline() : startGame(state.mode));
  $('backToHomeButton').addEventListener('click', () => { closeRoom(); showSection('homeSection'); });
  $('undoButton').addEventListener('click', undo);
  $('flipBoardButton').addEventListener('click', () => { state.flipped = !state.flipped; if (state.lastData) render(state.lastData); });
  $('resignButton').addEventListener('click', resign);
  $('themeToggle').addEventListener('click', () => {
    const theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('chess-arena-theme', theme); } catch { /* The theme still changes for this page. */ }
  });
  try {
    const saved = localStorage.getItem('chess-arena-theme');
    if (saved === 'dark' || saved === 'light') document.documentElement.dataset.theme = saved;
  } catch { /* Private browsing can disable local storage. */ }
  $('menuButton').addEventListener('click', () => { $('sidebar').classList.add('sidebar-open'); $('sidebarOverlay').classList.add('overlay-visible'); });
  $('sidebarOverlay').addEventListener('click', () => { $('sidebar').classList.remove('sidebar-open'); $('sidebarOverlay').classList.remove('overlay-visible'); });
  $('registerButton').addEventListener('click', () => authenticate('/api/register'));
  $('loginButton').addEventListener('click', () => authenticate('/api/login'));
  $('logoutButton').addEventListener('click', logout);
  $('copyRoomButton').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(state.room); toast('Room code copied.', 'success'); }
    catch { window.prompt('Copy this room code:', state.room); }
  });
  loadProfile();
  loadLeaderboard();
  loadHistory();
}

document.addEventListener('DOMContentLoaded', init);
