'use strict';

window.ChessArenaMultiplayer = {
  connect({ roomCode, clockSeconds, onState, onNotice, onOver, onClock }) {
    if (!window.io) throw new Error('The Socket.IO browser library did not load. Check your connection and reload.');
    const socket = window.io(location.origin, { transports:['websocket', 'polling'] });
    socket.on('connect', () => {
      if (roomCode) socket.emit('room_join', { room:roomCode });
      else socket.emit('room_create', { clock_seconds:clockSeconds });
    });
    socket.on('room_ready', onState);
    socket.on('room_state', onState);
    socket.on('room_player', event => onNotice(event.connected ? 'Your opponent joined.' : 'Your opponent disconnected. You can wait for them to reconnect or start a new room.'));
    socket.on('room_error', event => onNotice(event.error, true));
    socket.on('room_over', onOver);
    socket.on('room_clock', onClock);
    socket.on('connect_error', () => onNotice('Could not connect to the game server.', true));
    return socket;
  },
  move(socket, room, move) { socket.emit('room_move', { room, move }); },
  resign(socket, room) { socket.emit('room_resign', { room }); }
};
