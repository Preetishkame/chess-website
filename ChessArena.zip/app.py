"""Chess Arena: Flask application, API, and optional Socket.IO server."""
from __future__ import annotations

import logging
import os
import re
import secrets
import sqlite3
import threading
import time
from pathlib import Path

import chess
import chess.pgn
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash

try:
    from flask_socketio import SocketIO, emit, join_room
except ImportError:  # Socket.IO is a deployment dependency; HTTP play still works without it.
    SocketIO = None

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
app = Flask(__name__, template_folder=str(BASE_DIR / "templates"), static_folder=str(BASE_DIR / "static"))
app.config.update(
    SECRET_KEY=os.getenv("SECRET_KEY") or secrets.token_hex(32),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=1_000_000,
)
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("chess_arena")
cors_setting = os.getenv("CORS_ORIGINS", "").strip()
socketio = SocketIO(app, async_mode="threading", cors_allowed_origins=[origin.strip() for origin in cors_setting.split(",") if origin.strip()] if cors_setting else None, manage_session=True) if SocketIO else None
games: dict[str, chess.Board] = {}
rooms: dict[str, dict] = {}
lock = threading.RLock()


def db_connect():
    if DATABASE_URL:
        try:
            import psycopg
            return psycopg.connect(DATABASE_URL, autocommit=True), True
        except Exception as exc:
            raise RuntimeError("PostgreSQL is configured but unavailable. Check DATABASE_URL and install dependencies.") from exc
    path = os.getenv("SQLITE_PATH", str(BASE_DIR / "chess_arena.db"))
    connection = sqlite3.connect(path, timeout=10, isolation_level=None)
    connection.row_factory = sqlite3.Row
    return connection, False


def init_db():
    conn, pg = db_connect()
    try:
        serial = "BIGSERIAL PRIMARY KEY" if pg else "INTEGER PRIMARY KEY AUTOINCREMENT"
        conn.execute(f"CREATE TABLE IF NOT EXISTS users (id {serial}, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
        conn.execute(f"CREATE TABLE IF NOT EXISTS completed_games (id {serial}, game_id TEXT, user_id INTEGER, result TEXT NOT NULL, opponent TEXT NOT NULL, pgn TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
        if pg:
            conn.execute("ALTER TABLE completed_games ADD COLUMN IF NOT EXISTS game_id TEXT")
        else:
            columns = {row[1] for row in conn.execute("PRAGMA table_info(completed_games)").fetchall()}
            if "game_id" not in columns:
                conn.execute("ALTER TABLE completed_games ADD COLUMN game_id TEXT")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS completed_games_user_game ON completed_games(user_id, game_id)")
    finally:
        conn.close()


@app.get("/")
def home():
    response = app.make_response(render_template("index.html"))
    response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/api/health")
def health():
    return jsonify(status="ok", application="Chess Arena", database="postgresql" if DATABASE_URL else "sqlite")


@app.get("/api/status")
def status():
    return jsonify(name="Chess Arena", version="1.0.0", features={"legal_chess": True, "bot": True, "accounts": True, "game_history": True, "leaderboard": True, "database": "postgresql" if DATABASE_URL else "sqlite", "multiplayer": bool(socketio), "online_clocks": bool(socketio)})


def board_payload(board: chess.Board):
    replay = board.copy(stack=True)
    history = list(replay.move_stack)
    while replay.move_stack:
        replay.pop()
    san_moves = []
    for move in history:
        san_moves.append(replay.san(move))
        replay.push(move)
    return {"fen": board.fen(), "turn": "white" if board.turn else "black", "check": board.is_check(),
            "game_over": board.is_game_over(claim_draw=True), "result": board.result(claim_draw=True) if board.is_game_over(claim_draw=True) else None,
            "status": board.outcome(claim_draw=True).termination.name.replace("_", " ").title() if board.is_game_over(claim_draw=True) else None,
            "moves": san_moves, "legal_moves": [m.uci() for m in board.legal_moves]}


def board_pgn(board: chess.Board, result: str | None = None, termination: str | None = None):
    game = chess.pgn.Game.from_board(board)
    if result:
        game.headers["Result"] = result
    if termination:
        game.headers["Termination"] = termination
    return game.accept(chess.pgn.StringExporter(headers=True, variations=False, comments=False))


def save_completed_game(game_id, user_id, result, opponent, pgn):
    if not user_id:
        return
    conn, pg = db_connect()
    try:
        sql = ("INSERT INTO completed_games (game_id,user_id,result,opponent,pgn) VALUES (%s,%s,%s,%s,%s) ON CONFLICT (user_id,game_id) DO NOTHING"
               if pg else "INSERT OR IGNORE INTO completed_games (game_id,user_id,result,opponent,pgn) VALUES (?,?,?,?,?)")
        conn.execute(sql, (game_id, user_id, result, opponent[:40], pgn))
    finally:
        conn.close()


def result_for_white(result):
    return {"1-0": "win", "0-1": "loss", "1/2-1/2": "draw"}.get(result)


def room_payload(room):
    return {**board_payload(room["board"]), "room": room["code"], "players": len(room["players"]),
            "clocks": room["clocks"], "clock_enabled": room["clock_enabled"], "finished": room["finished"]}


def save_room_results(room, result, reason):
    pgn = board_pgn(room["board"], result, reason)
    for player in room["players"].values():
        outcome = result_for_white(result)
        if player["color"] == "black":
            outcome = {"win": "loss", "loss": "win", "draw": "draw"}[outcome]
        save_completed_game(room["code"], player.get("user_id"), outcome, "Online opponent", pgn)


def expire_room_clock(room):
    if not room["clock_enabled"] or room["finished"]:
        return None
    side = "white" if room["board"].turn else "black"
    index = 0 if side == "white" else 1
    elapsed = max(0, time.monotonic() - room["turn_started"])
    room["clocks"][index] = max(0, room["clocks"][index] - elapsed)
    room["turn_started"] = time.monotonic()
    if room["clocks"][index] > 0:
        return None
    winner = "black" if side == "white" else "white"
    result = "0-1" if winner == "black" else "1-0"
    if room["board"].has_insufficient_material(chess.WHITE if winner == "white" else chess.BLACK):
        result = "1/2-1/2"
        winner = None
    room["finished"] = True
    save_room_results(room, result, "Time forfeit")
    return {"winner": winner, "result": result, "reason": "timeout", "clocks": room["clocks"]}


@app.post("/api/games")
def create_game():
    data = request.get_json(silent=True) or {}
    mode = data.get("mode", "bot")
    difficulty = data.get("difficulty", "medium")
    if mode not in ("bot", "local", "online") or difficulty not in ("easy", "medium", "hard"):
        return jsonify(error="Invalid game mode or difficulty."), 400
    game_id = secrets.token_urlsafe(12)
    with lock:
        games[game_id] = chess.Board()
    return jsonify(game_id=game_id, mode=mode, difficulty=difficulty, **board_payload(games[game_id]))


@app.get("/api/games/<game_id>")
def get_game(game_id):
    board = games.get(game_id)
    return (jsonify(error="Game not found."), 404) if board is None else jsonify(game_id=game_id, **board_payload(board))


@app.post("/api/games/<game_id>/move")
def make_move(game_id):
    data = request.get_json(silent=True) or {}
    uci = data.get("move", "")
    with lock:
        board = games.get(game_id)
        if board is None:
            return jsonify(error="Game not found."), 404
        try:
            move = chess.Move.from_uci(uci)
        except (ValueError, TypeError):
            return jsonify(error="Move must be valid UCI notation."), 400
        if board.is_game_over(claim_draw=True) or move not in board.legal_moves:
            return jsonify(error="That move is not legal."), 400
        san = board.san(move)
        board.push(move)
        state = board_payload(board)
    return jsonify(san=san, **state)


@app.post("/api/games/<game_id>/undo")
def undo_move(game_id):
    board = games.get(game_id)
    if board is None:
        return jsonify(error="Game not found."), 404
    with lock:
        if board.move_stack: board.pop()
        if board.move_stack: board.pop()
        return jsonify(**board_payload(board))


@app.post("/api/games/<game_id>/bot")
def bot_move(game_id):
    import random
    data = request.get_json(silent=True) or {}
    difficulty = data.get("difficulty", "medium")
    if difficulty not in ("easy", "medium", "hard"):
        return jsonify(error="Invalid difficulty."), 400
    with lock:
        board = games.get(game_id)
        if board is None: return jsonify(error="Game not found."), 404
        if board.is_game_over(claim_draw=True): return jsonify(error="Game is over."), 400
        moves = list(board.legal_moves)
        if difficulty == "easy":
            chosen = random.choice(moves)
        else:
            scored = []
            for move in moves:
                board.push(move)
                score = -evaluate(board)
                board.pop()
                scored.append((score, move))
            if difficulty == "hard":
                scored.sort(key=lambda x: x[0], reverse=True)
                chosen = search_best(board, 2 if board.fullmove_number < 15 else 3) or scored[0][1]
            else:
                best = max(score for score, _ in scored)
                chosen = random.choice([move for score, move in scored if score >= best - 1.4])
        san = board.san(chosen); board.push(chosen)
        return jsonify(san=san, **board_payload(board))


PIECE_VALUES = {chess.PAWN: 1, chess.KNIGHT: 3.2, chess.BISHOP: 3.35, chess.ROOK: 5, chess.QUEEN: 9, chess.KING: 0}


def evaluate(board):
    if board.is_checkmate(): return -1000
    score = 0
    for piece_type, value in PIECE_VALUES.items():
        score += value * (len(board.pieces(piece_type, chess.WHITE)) - len(board.pieces(piece_type, chess.BLACK)))
    score += 0.08 * (board.legal_moves.count() if board.turn else -board.legal_moves.count())
    return score if board.turn == chess.WHITE else -score


def search_best(board, depth):
    def minimax(level, alpha, beta):
        if level == 0 or board.is_game_over(claim_draw=True): return evaluate(board)
        best = -float("inf")
        for move in ordered_moves(board):
            board.push(move); score = -minimax(level - 1, -beta, -alpha); board.pop()
            best = max(best, score); alpha = max(alpha, score)
            if alpha >= beta: break
        return best
    best_move, best_score = None, -float("inf")
    for move in ordered_moves(board):
        board.push(move); score = -minimax(depth - 1, -float("inf"), float("inf")); board.pop()
        if score > best_score: best_move, best_score = move, score
    return best_move


def ordered_moves(board):
    return sorted(board.legal_moves, key=lambda m: (board.is_capture(m), m.promotion is not None), reverse=True)


def current_user(): return session.get("user_id")


@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}
    username, password = str(data.get("username", "")).strip(), str(data.get("password", ""))
    if not re.fullmatch(r"[A-Za-z0-9_]{3,24}", username) or len(password) < 10:
        return jsonify(error="Use a 3–24 character username and a password of at least 10 characters."), 400
    try:
        conn, _ = db_connect()
        try:
            cursor = conn.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)" if isinstance(conn, sqlite3.Connection) else "INSERT INTO users (username,password_hash) VALUES (%s,%s) RETURNING id", (username, generate_password_hash(password)))
            user_id = cursor.lastrowid if isinstance(conn, sqlite3.Connection) else cursor.fetchone()[0]
        finally: conn.close()
    except Exception as exc:
        logger.info("Registration failed: %s", exc)
        return jsonify(error="That username is already in use or the database is unavailable."), 409
    session.clear(); session["user_id"] = user_id; session["username"] = username
    return jsonify(username=username), 201


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    try:
        conn, _ = db_connect()
        try: row = conn.execute("SELECT id, username, password_hash FROM users WHERE username = ?" if isinstance(conn, sqlite3.Connection) else "SELECT id,username,password_hash FROM users WHERE username = %s", (username,)).fetchone()
        finally: conn.close()
    except Exception: return jsonify(error="Database unavailable."), 503
    if not row or not check_password_hash(row["password_hash"] if isinstance(row, sqlite3.Row) else row[2], str(data.get("password", ""))):
        return jsonify(error="Username or password is incorrect."), 401
    session.clear(); session["user_id"] = row["id"] if isinstance(row, sqlite3.Row) else row[0]; session["username"] = row["username"] if isinstance(row, sqlite3.Row) else row[1]
    return jsonify(username=session["username"])


@app.post("/api/logout")
def logout(): session.clear(); return jsonify(ok=True)


@app.get("/api/me")
def profile():
    if not current_user(): return jsonify(user=None, games=0, wins=0, losses=0, draws=0, win_rate=0)
    try:
        conn, _ = db_connect()
        ph = "?" if isinstance(conn, sqlite3.Connection) else "%s"
        try:
            rows = conn.execute(f"SELECT result FROM completed_games WHERE user_id={ph}", (current_user(),)).fetchall()
        finally:
            conn.close()
        results = [row[0] if not isinstance(row, sqlite3.Row) else row["result"] for row in rows]
        wins = results.count("win")
        losses = results.count("loss")
        draws = results.count("draw")
    except Exception:
        logger.exception("Profile statistics are unavailable")
        return jsonify(error="Profile statistics are temporarily unavailable."), 503
    return jsonify(user=session.get("username"), games=len(rows), wins=wins, losses=losses, draws=draws, win_rate=round(wins * 100 / len(rows)) if rows else 0)


@app.get("/api/history")
def game_history():
    if not current_user():
        return jsonify(error="Sign in to see your game history."), 401
    try:
        conn, pg = db_connect()
        try:
            marker = "%s" if pg else "?"
            rows = conn.execute(f"SELECT result,opponent,created_at,pgn FROM completed_games WHERE user_id={marker} ORDER BY id DESC LIMIT 50", (current_user(),)).fetchall()
        finally:
            conn.close()
        if pg:
            items = [dict(result=row[0], opponent=row[1], played_at=row[2].isoformat(), pgn=row[3]) for row in rows]
        else:
            items = [dict(result=row["result"], opponent=row["opponent"], played_at=row["created_at"], pgn=row["pgn"]) for row in rows]
        return jsonify(games=items)
    except Exception:
        logger.exception("Game history is unavailable")
        return jsonify(error="Game history is temporarily unavailable."), 503


@app.post("/api/games/<game_id>/finish")
def finish_game(game_id):
    if not current_user(): return jsonify(saved=False)
    data = request.get_json(silent=True) or {}
    board = games.get(game_id)
    if board is None:
        return jsonify(error="Game not found."), 404
    reason = data.get("reason", "finished")
    result = result_for_white(board.result(claim_draw=True)) if board.is_game_over(claim_draw=True) else None
    if reason in ("resign", "timeout"):
        proposed = data.get("result")
        if proposed not in ("win", "loss", "draw"):
            return jsonify(error="Invalid result."), 400
        if result is not None:
            return jsonify(error="This game has already ended."), 409
        result = proposed
    if result is None:
        return jsonify(error="The game is not over yet."), 409
    if data.get("result") and data.get("result") != result:
        return jsonify(error="The reported result does not match the game."), 400
    result_code = board.result(claim_draw=True) if board.is_game_over(claim_draw=True) else {"win": "1-0", "loss": "0-1", "draw": "1/2-1/2"}[result]
    pgn = board_pgn(board, result_code, "Time forfeit" if reason == "timeout" else ("Resignation" if reason == "resign" else reason))
    try:
        save_completed_game(game_id, current_user(), result, str(data.get("opponent", "Opponent")), pgn)
    except Exception:
        logger.exception("Could not save completed game")
        return jsonify(error="Could not save the completed game."), 503
    return jsonify(saved=True)


@app.get("/api/leaderboard")
def leaderboard():
    try:
        conn, _ = db_connect()
        try:
            rows = conn.execute("SELECT u.username, COUNT(g.id) games, SUM(CASE WHEN g.result='win' THEN 1 ELSE 0 END) wins FROM users u LEFT JOIN completed_games g ON g.user_id=u.id GROUP BY u.id,u.username ORDER BY wins DESC,games DESC LIMIT 20").fetchall()
        finally: conn.close()
        return jsonify(players=[dict(username=r[0], games=r[1], wins=r[2] or 0) for r in rows])
    except Exception: return jsonify(error="Leaderboard unavailable."), 503


@app.errorhandler(404)
def not_found(error): return jsonify(error="Not found."), 404


@app.errorhandler(500)
def internal_error(error):
    logger.exception("Internal server error")
    return jsonify(error="Internal server error. Please try again."), 500


if socketio:
    @socketio.on("room_create")
    def room_create(data):
        data = data if isinstance(data, dict) else {}
        try:
            seconds = max(0, min(3600, int(data.get("clock_seconds", 600))))
        except (TypeError, ValueError):
            seconds = 600
        code = secrets.token_urlsafe(5).upper()
        room = {"code": code, "players": {request.sid: {"color": "white", "user_id": session.get("user_id")}},
                "board": chess.Board(), "clock_enabled": seconds > 0, "clocks": [float(seconds), float(seconds)],
                "turn_started": time.monotonic(), "finished": False}
        rooms[code] = room
        join_room(code)
        emit("room_ready", {"color": "white", **room_payload(room)})

    @socketio.on("room_join")
    def room_join(data):
        code = str((data or {}).get("room", "")).upper()
        room = rooms.get(code)
        if not room or room["finished"] or len(room["players"]) >= 2:
            emit("room_error", {"error": "Room not found or full."}); return
        if request.sid in room["players"]:
            emit("room_error", {"error": "You are already in this room."}); return
        taken = {player["color"] for player in room["players"].values()}
        color = "white" if "white" not in taken else "black"
        room["players"][request.sid] = {"color": color, "user_id": session.get("user_id")}
        join_room(code)
        emit("room_ready", {"color": color, **room_payload(room)})
        emit("room_player", {"connected": True}, to=code, include_self=False)
        emit("room_state", room_payload(room), to=code)

    @socketio.on("room_move")
    def room_move(data):
        data = data if isinstance(data, dict) else {}
        code = str(data.get("room", "")).upper(); room = rooms.get(code)
        if not room or request.sid not in room["players"]:
            emit("room_error", {"error": "You are not a player in this room."}); return
        if room["finished"]:
            emit("room_error", {"error": "This game has ended."}); return
        board = room["board"]; side = room["players"][request.sid]["color"]
        timeout = expire_room_clock(room)
        if timeout:
            emit("room_over", timeout, to=code); return
        try: move = chess.Move.from_uci(data.get("move", ""))
        except (ValueError, TypeError): emit("room_error", {"error": "Invalid move."}); return
        if ("white" if board.turn else "black") != side or move not in board.legal_moves:
            emit("room_error", {"error": "That move is not legal for your side."}); return
        board.push(move)
        room["turn_started"] = time.monotonic()
        if board.is_game_over(claim_draw=True):
            room["finished"] = True
            result = board.result(claim_draw=True)
            save_room_results(room, result, board.outcome(claim_draw=True).termination.name.replace("_", " ").title())
            winner = {"1-0":"white", "0-1":"black", "1/2-1/2":None}[result]
            emit("room_over", {"winner": winner, "result": result, "reason": "board", "clocks": room["clocks"]}, to=code)
        emit("room_state", room_payload(room), to=code)

    @socketio.on("room_clock_check")
    def room_clock_check(data):
        data = data if isinstance(data, dict) else {}
        code = str(data.get("room", "")).upper(); room = rooms.get(code)
        if not room or request.sid not in room["players"] or room["finished"]:
            return
        timeout = expire_room_clock(room)
        if timeout:
            emit("room_over", timeout, to=code)
        else:
            emit("room_clock", {"clocks": room["clocks"], "turn": "white" if room["board"].turn else "black"}, to=code)

    @socketio.on("room_resign")
    def room_resign(data):
        data = data if isinstance(data, dict) else {}
        code = str(data.get("room", "")).upper(); room = rooms.get(code)
        if not room or request.sid not in room["players"] or room["finished"]:
            emit("room_error", {"error": "You cannot resign this game."}); return
        side = room["players"][request.sid]["color"]
        winner = "black" if side == "white" else "white"
        result = "0-1" if winner == "black" else "1-0"
        room["finished"] = True
        save_room_results(room, result, "Resignation")
        emit("room_over", {"winner": winner, "result": result, "reason": "resignation", "clocks": room["clocks"]}, to=code)

    @socketio.on("disconnect")
    def on_disconnect():
        for code, room in list(rooms.items()):
            if request.sid in room["players"]:
                del room["players"][request.sid]; emit("room_player", {"connected": False}, to=code)
                if not room["players"]: del rooms[code]


def run():
    try:
        init_db()
    except Exception as exc:
        logger.error("Database initialization failed: %s", exc)
    if socketio: socketio.run(app, host="0.0.0.0", port=int(os.getenv("PORT", "5000")), allow_unsafe_werkzeug=True)
    else: app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")))


if __name__ == "__main__": run()
else:
    try:
        init_db()
    except Exception as exc:
        logger.warning("Database initialization deferred: %s", exc)
